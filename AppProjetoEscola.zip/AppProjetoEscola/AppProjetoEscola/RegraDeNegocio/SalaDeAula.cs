﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProjetoEscola.RegraDeNegocio
{
    public class SalaDeAula
    {
        //atributos
        public int Id { get; set; } 
        public int Serie { get; set; }
        public string NomeTurma { get; set; }
        
        public List <Aluno> AlunosMatriculados { get; set; }

        //método construtor
        public SalaDeAula(int id, int serie, string nomeTurma)
        {
            this.Id = id;
            this.Serie = serie;
            this.NomeTurma = nomeTurma;
            AlunosMatriculados = new List<Aluno>();
        }
    }
}
