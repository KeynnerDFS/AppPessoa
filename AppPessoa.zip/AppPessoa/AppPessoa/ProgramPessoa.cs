﻿using AppPessoa.RegrasDeNegocio;
using System.Security.Cryptography.X509Certificates;

int opcao = 0;

List<Pessoa>ListaPessoa = new List<Pessoa>();

void CadastrarPessoas()
{
    int opc = 1;
    while(opc!= 0)
    {
        Console.Clear();
        Console.WriteLine("%%%%%%%%%%%%%%% CADASTRAR PESSOA %%%%%%%%%%%%%%%");
        Console.WriteLine();
        Pessoa pessoa = new Pessoa();
        pessoa.Id = ListaPessoa.Count + 1;
        Console.WriteLine("Número de Inscrição.......:" + pessoa.Id );

        Console.Write("Nome.................:");
        pessoa.Nome = Console.ReadLine();

        Console.Write("CPF.................:");
        pessoa.Cpf = Console.ReadLine();

        Console.Write("RG.................:");
        pessoa.Rg = Console.ReadLine();

        Console.Write("Salario.................:");
        pessoa.Salario = Convert.ToDouble(Console.ReadLine());

        //com o objeto devidamente preenchido, já podemos inserir na lista
     
        ListaPessoa.Add(pessoa);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine();
        Console.WriteLine("[Cadastro com sucesso!!!]");
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write("Deseja continuar cadastrando? (S/N).....:");
        string resp = Console.ReadLine();
        if (resp.ToUpper() == "N") opc = 0;

    }//fim do while
}//fim cadastrar pessoa

//Função listar pessoas
void ListarPessoas()
{
    Console.Clear();
    Console.WriteLine("%%%%%%%%%%%%%%% LISTA DE PESSOA %%%%%%%%%%%%%%%");
    Console.WriteLine();
    //foreach (var pessoa in ListaPessoa) sem ordenação
    foreach (var pessoa in ListaPessoa.OrderBy(a=>a.Nome).ToList())
    {
       
        Console.WriteLine("Número de Id.......:" + pessoa.Id);
        Console.WriteLine("Nome.....:" + pessoa.Nome);
        Console.WriteLine("CPF......:" + pessoa.Cpf);
        Console.WriteLine("RG.......:" + pessoa.Rg);
        Console.WriteLine("Salario..:" + pessoa.Salario.ToString("C2"));
        Console.WriteLine("___________________________________________________");
    }
    Console.ReadKey();

    /* Com o FOR
    for (int i = 0; i < ListaPessoa.Count;i++)
    {
        Pessoa pessoa=new Pessoa();
        pessoa = ListaPessoa[i];
        Console.WriteLine("Nome:"+pessoa.Nome);
    }*/
}//fim cadastrar pessoa
/*void ConsultarPorNome()
{
    Console.Clear();
    Console.Write("Digite o nome de quem preocura:");
    string nome = Console.ReadLine();
    foreach (var pessoa in ListaPessoa)
    {
        Console.Clear();
        if(nome.ToUpper() == pessoa.Nome.ToUpper())
        {
            Console.WriteLine();
            Console.WriteLine("Número de Id.......:" + pessoa.Id);
            Console.WriteLine("Nome.....:" + pessoa.Nome);
            Console.WriteLine("CPF......:" + pessoa.Cpf);
            Console.WriteLine("RG.......:" + pessoa.Rg);
            Console.WriteLine("Salario..:" + pessoa.Salario.ToString("C2"));
       
        }
    }
    Console.ReadKey();
}//Fim ConsultarPornome
void ConsultarPorCpf()
{
    Console.Clear();
    Console.Write("Digite o CPF de quem preocura:");
    string Cpf = Console.ReadLine();
    foreach (var pessoa in ListaPessoa)
    {
        Console.Clear();
        if (Cpf == pessoa.Cpf)
        {
            Console.WriteLine();
            Console.WriteLine("Número de Id.......:" + pessoa.Id);
            Console.WriteLine("Nome.....:" + pessoa.Nome);
            Console.WriteLine("CPF......:" + pessoa.Cpf);
            Console.WriteLine("RG.......:" + pessoa.Rg);
            Console.WriteLine("Salario..:" + pessoa.Salario.ToString("C2"));

        }
    }
    Console.ReadKey();
}//fim ConsultarPorCpf*/
//Função consultar pessoa por nome
void ConsultarPorNome()
{
    
    Console.Clear();
    Console.WriteLine("%%%%%%%%%%%%%%% CONSULTAR POR NOME %%%%%%%%%%%%%%%");
    Console.WriteLine();
    Console.Write("Pesquisar nome.......................:");
    var nome = Console.ReadLine();
    Console.WriteLine();
    //var pessoasSelecao = ListaPessoa.Where(x=>x.Nome.Contains(nome)).ToArray();
    var pessoasSelecao = ListaPessoa.Where(x => x.Nome.ToUpper().Contains(nome.ToUpper())).ToList();
    
    foreach (var pessoa in pessoasSelecao)
    {
            Console.WriteLine("Número de Id.......:" + pessoa.Id);
            Console.WriteLine("Nome.....:" + pessoa.Nome);
            Console.WriteLine("CPF......:" + pessoa.Cpf);
            Console.WriteLine("RG.......:" + pessoa.Rg);
            Console.WriteLine("Salario..:" + pessoa.Salario.ToString("C2"));
            Console.WriteLine("___________________________________________________");
  
    }
    if (pessoasSelecao.Count() < 1)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("[Nome inexistente]");
        Console.ForegroundColor = ConsoleColor.White;  
    }



    Console.ReadKey();
}// fim consultar por nome


void ConsultarPorCPF()
{
    Console.Clear();
    Console.WriteLine("%%%%%%%%%%%%%%% CONSULTAR POR CPF %%%%%%%%%%%%%%%");
    Console.WriteLine();
    Console.Write("Pesquisar CPF.......................:");
    var cpf = Console.ReadLine();
    Console.WriteLine();
    var pessoaCpf = ListaPessoa.Where(c=>c.Cpf == cpf).FirstOrDefault();
    if(pessoaCpf != null)
    {
        Console.WriteLine("Número de Id.......:" + pessoaCpf.Id);
        Console.WriteLine("Nome.....:" + pessoaCpf.Nome);
        Console.WriteLine("CPF......:" + pessoaCpf.Cpf);
        Console.WriteLine("RG.......:" + pessoaCpf.Rg);
        Console.WriteLine("Salario..:" + pessoaCpf.Salario.ToString("C2"));
        Console.WriteLine("___________________________________________________");
    }
    else
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("[CPF não encontrado]");
        Console.ForegroundColor= ConsoleColor.White;
    }
 
    Console.ReadKey();
}
void ConsultarPorSalario()
{
    Console.Clear();
    Console.WriteLine("%%%%%%%%%%%%%%% CONSULTAR POR SALARIO %%%%%%%%%%%%%%%");
    Console.WriteLine();
    Console.Write("Pesquisar Salario.......................:");
    var Salario = Convert.ToDouble(Console.ReadLine());
    Console.WriteLine();
    var pessoasSalario = ListaPessoa.Where(s => s.Salario >= Salario).ToList();
    foreach (var pessoa in pessoasSalario)
    {
        Console.WriteLine("Número de Id.......:" + pessoa.Id);
        Console.WriteLine("Nome.....:" + pessoa.Nome);
        Console.WriteLine("CPF......:" + pessoa.Cpf);
        Console.WriteLine("RG.......:" + pessoa.Rg);
        Console.WriteLine("Salario..:" + pessoa.Salario.ToString("C2"));
        Console.WriteLine("___________________________________________________");
    }
    Console.ReadKey();
}

while (opcao != 7)
{
    Console.Clear();//Limpar tela
    Console.WriteLine("@@@@@@@@@@ MENU @@@@@@@@@@");
    Console.WriteLine();
    Console.WriteLine("1 - Cadastrar Pessoa");
    Console.WriteLine("2 - Listar Pessoa");
    Console.WriteLine("3 - Consultar Pessoa por Nome");
    Console.WriteLine("4 - Consultar Pessoa por CPF");
    Console.WriteLine("5 - Filtar pessoas por salário");
    Console.WriteLine("7 - Fechar Sistema");
    Console.Write("Opção N°......................................:");
    opcao = Convert.ToInt32(Console.ReadLine());
    switch (opcao)
    {
        case 1:
            {
                CadastrarPessoas();
                break;
            }//fim do case 1
        case 2:
            {
                ListarPessoas();
                break;
            }//fim do case 2
        case 3:
            {
               ConsultarPorNome();  
                break;
            }//fim do case 3
        case 4:
            {
                ConsultarPorCPF();
             
                break;
            }//fim do case 4
        case 5:
            {
                ConsultarPorSalario();
                break;
            }//fim do case 5
        case 7:
            {
                Console.Clear();
                Console.WriteLine("Desaja mesmo Fechar o SISTEMA? S/N");
                string resposta = Console.ReadLine();
                if (resposta.ToUpper() == "N") opcao = 0;
                break;
            }//fim do case 7
        default:
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("OPÇÃO INVÁLIDA");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
                break;
            }//Fim do default
    }//fim do switch

}//fim do laço principal